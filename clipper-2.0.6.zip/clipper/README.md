# [Clipper](https://www.appthemes.com/themes/clipper/) [![Build Status](http://ci.appthemesdev.com/buildStatus/icon?job=Clipper-build-master)](http://ci.appthemesdev.com/job/Clipper-build-master/)

A professional coupon deals theme built by [AppThemes](https://www.appthemes.com/).
