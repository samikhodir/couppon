<?php

/**
 * This file is not supposed to be included anywhere, it needs only to register
 * some text strings that came from API server.
 */

// Some strings supposed to be translated, so they needs to be
// registered by gettext function.
// DO NOT CHANGE THE CONTEXT TEXT. IT NEEDS FOR CORRECT TRANSLATION!
_x( 'View',            'MarketPlace Addons page translation', APP_TD );
_x( 'New',             'MarketPlace Addons page translation', APP_TD );
_x( 'Popular',         'MarketPlace Addons page translation', APP_TD );
_x( 'Search Add-ons',  'MarketPlace Addons page translation', APP_TD );
_x( 'Category',        'MarketPlace Addons page translation', APP_TD );
_x( 'Plugins',         'MarketPlace Addons page translation', APP_TD );
_x( 'Gateway Plugins', 'MarketPlace Addons page translation', APP_TD );
_x( 'Payment Gateways','MarketPlace Addons page translation', APP_TD );
_x( 'Child Themes',    'MarketPlace Addons page translation', APP_TD );
_x( 'General Themes',  'MarketPlace Addons page translation', APP_TD );
_x( 'Product',         'MarketPlace Addons page translation', APP_TD );
_x( 'Author',          'MarketPlace Addons page translation', APP_TD );
_x( 'Rating',          'MarketPlace Addons page translation', APP_TD );
_x( '4+ stars',        'MarketPlace Addons page translation', APP_TD );
_x( '3+ stars',        'MarketPlace Addons page translation', APP_TD );
_x( '2+ stars',        'MarketPlace Addons page translation', APP_TD );
_x( '1+ stars',        'MarketPlace Addons page translation', APP_TD );
_x( 'All Categories',  'MarketPlace Addons page translation', APP_TD );
_x( 'All Products',    'MarketPlace Addons page translation', APP_TD );
_x( 'All Authors',     'MarketPlace Addons page translation', APP_TD );
_x( 'All Ratings',     'MarketPlace Addons page translation', APP_TD );
