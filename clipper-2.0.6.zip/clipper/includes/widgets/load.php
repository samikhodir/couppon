<?php
require_once APP_FRAMEWORK_DIR . '/load-p2p.php';
require_once APP_FRAMEWORK_DIR . '/admin/class-widget.php';

P2P_Autoload::register( 'APP_', dirname( __FILE__ ) );