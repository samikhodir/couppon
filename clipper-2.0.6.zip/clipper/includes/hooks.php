<?php
/**
 * Theme-specific hooks.
 * For general AppThemes hooks, see framework/kernel/hooks.php
 *
 * @package Clipper\Hooks
 * @author  AppThemes
 * @since   Clipper 1.1
 */


