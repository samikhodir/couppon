# Theme Framework
These are functions and classes that are shared across all our themes.
